//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by kgb_arch_decompress.rc
//
#define IDR_MANIFEST                    1
#define IDM_ABOUTBOX                    0x0010
#define IDS_ABOUTBOX                    101
#define IDD_KGB_ARCH_DECOMPRESS_DIALOG  102
#define IDS_FILE                        102
#define IDS_SIZE                        103
#define IDS_CHOOSE_EXTRACT_DIR          104
#define IDS_ARCHIVE_NOT_FOUND           105
#define IDD_DECOMPRESS                  106
#define IDS_CANT_CREATE_EXTRACT_DIR     106
#define IDS_CHOOSE_FILES2DECOMPRESS     107
#define IDS_EXTRACT_CANCELED            108
#define IDS_EXTRACT_SUCCED              109
#define IDS_CHOOSE_DIR2DECOMPRESS       110
#define IDS_CANT_CHANGE_PRIORITY        111
#define IDS_DECOMPRESS_PROGRESS         112
#define IDS_DECOMPRESS_STATUS           113
#define IDS_DECOMPRESS_STATUS2          114
#define IDS_DECOMPRESS_STATUS3          115
#define IDS_WRONG_PASSWD                116
#define IDR_MAINFRAME                   130
#define IDD_PASSWD                      133
#define IDR_RT_MANIFEST1                137
#define IDR_RT_MANIFEST2                138
#define IDC_EARCHNAME                   1000
#define IDC_BBROWSE                     1001
#define IDC_EARCHNAME2                  1002
#define IDC_BBROWSE2                    1003
#define IDC_LIST1                       1004
#define IDC_BUTTON1                     1005
#define IDC_BUTTON2                     1006
#define IDC_CHECK1                      1008
#define IDC_EPASSWD                     1010
#define IDC_PROGRESS1                   1012
#define IDC_PROGRESS2                   1013
#define IDC_FILENAME                    1015
#define IDC_FULLSIZE                    1016
#define IDC_COMPRESSEDSIZE              1017
#define IDC_RATIO                       1018
#define IDC_ELAPSEDTIME                 1019
#define IDC_REMAININGTIME               1020
#define IDC_CPRIORITY                   1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
