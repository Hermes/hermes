//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by kgb_arch_decompress.rc
//
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_KGB_ARCH_DECOMPRESS_DIALOG  102
#define IDS_FILE                        102
#define IDS_SIZE                        103
#define IDS_TYPE_ARCHIVE_NAME           104
#define IDS_ARCHIVE_DOESNT_EXIST        105
#define IDD_DECOMPRESS                  106
#define IDS_CANT_EXTRACT_DIR_NOT_FOUND  106
#define IDS_CHOOSE_FILES2DECOMPRESS     107
#define IDS_EXTRACT_CANCELED            108
#define IDS_EXTRACT_SUCCED_STATS        109
#define IDS_CHOOSE_DIR2DECOMPRESS       110
#define IDS_WRONG_PASSWD                111
#define IDS_BROKEN_ARCHIVE              112
#define IDS_CANT_CHANGE_PRIORITY        113
#define IDS_DECOMPRESS_PROGRESS         114
#define IDS_DECOMPRESS_STATUS           115
#define IDS_DECOMPRESS_STATUS2          116
#define IDS_DECOMPRESS_STATUS3          117
#define IDS_FILETYPE                    118
#define IDS_ARCHIVE_INFO                119
#define IDS_OUT_OF_MEMORY               120
#define IDS_FILE_ALREADY_EXISTS         121
#define IDS_ARE_YOU_SURE_CANCEL         122
#define IDS_OVERWRITE_SIZE              123
#define IDS_OVERWRITE_MOD               124
#define IDS_OVERWRITE_BY_THIS_ONE       125
#define IDR_MAINFRAME                   130
#define IDD_PASSWD                      133
#define IDR_RT_MANIFEST1                136
#define IDD_ENCODING                    137
#define IDD_DECODING                    137
#define IDI_TRAY0                       138
#define IDI_TRAY1                       139
#define IDI_TRAY2                       140
#define IDI_TRAY3                       141
#define IDI_TRAY4                       142
#define IDI_TRAY5                       143
#define IDD_OVERWRITE                   145
#define IDC_EARCHNAME                   1000
#define IDC_BBROWSE                     1001
#define IDC_EARCHNAME2                  1002
#define IDC_BBROWSE2                    1003
#define IDC_LIST1                       1004
#define IDC_BUTTON1                     1005
#define IDC_BUTTON2                     1006
#define IDC_CHECK1                      1008
#define IDC_EPASSWD                     1010
#define IDC_ARCHIVE_INFO                1011
#define IDC_PROGRESS1                   1012
#define IDC_PROGRESS2                   1013
#define IDC_BYESALL                     1014
#define IDC_FILENAME                    1015
#define IDC_BYES                        1015
#define IDC_FULLSIZE                    1016
#define IDC_BNO                         1016
#define IDC_COMPRESSEDSIZE              1017
#define IDC_BNOALL                      1017
#define IDC_RATIO                       1018
#define IDC_SORIGINALFILE               1018
#define IDC_ELAPSEDTIME                 1019
#define IDC_SORIGINALSIZE               1019
#define IDC_REMAININGTIME               1020
#define IDC_SORIGINALMOD                1020
#define IDC_SNEWSIZE                    1021
#define IDC_CPRIORITY                   1022
#define IDC_SNEWMOD                     1022
#define IDC_BRECENTARCHIVES             1024
#define IDC_BRECENTDIRS                 1025
#define IDC_NEWICON                     1025
#define IDC_OLDICON2                    1028
#define IDC_OLDICON                     1029
#define IDM_ABOUTBOX                    0x1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
