//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by kgb_arch_mfc.rc
//
#define IDR_MAINFRAME                   5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_KGB_ARCH_MFC_DIALOG         102
#define IDS_FILE                        102
#define IDS_SIZE                        103
#define IDS_CANT_ACCESS_FILE            104
#define IDS_TYPE_ARCHIVE_NAME           105
#define IDD_COMPRESS                    106
#define IDS_PASSWDLEN                   106
#define IDS_COMPRESSION_CANCEL          107
#define IDS_COMPRESSION_SUCCED_STATS    108
#define IDS_CHOOSE_DIR2COMPRESS         109
#define IDS_CANT_CHANGE_PRIORITY        110
#define IDS_COMPRESS_PROGRESS           111
#define IDS_COMPRESS_STATUS             112
#define IDS_COMPRESS_STATUS2            113
#define IDS_COMPRESS_STATUS3            114
#define IDS_COMPRESS_STATUS4            115
#define IDS_COMPRESS_STATUS5            116
#define IDS_FILETYPES                   117
#define IDS_FILESTYPES_ALL              118
#define IDS_FILETYPES_ALL               118
#define IDS_ONLY_NUMBERS_ACCEPTED       119
#define IDS_NOT_ENOUGH_RAM              120
#define IDS_MEMORY_USAGE                121
#define IDS_OUT_OF_MEMORY               122
#define IDS_FILE_ALREADY_EXISTS         123
#define IDS_WRONG_ARCHIVE_NAME          124
#define IDS_ARE_YOU_SURE_CANCEL         125
#define IDS_TOO_BIG_FILE                126
#define IDI_TRAY0                       137
#define IDI_TRAY1                       138
#define IDI_TRAY2                       139
#define IDI_TRAY3                       140
#define IDI_TRAY4                       141
#define IDI_TRAY5                       142
#define IDC_EARCHNAME                   1000
#define IDC_BBROWSE                     1001
#define IDC_COPTIONS                    1002
#define IDC_PASSWORD                    1004
#define IDC_CSPAN                       1005
#define IDC_CFULLPATH                   1006
#define IDC_LIST1                       1007
#define IDC_BADD2COMPRESS               1008
#define IDC_BREMOVEFROMCOMPRESS         1009
#define IDC_BNEXT                       1010
#define IDC_BCANCEL                     1011
#define IDC_EDIT                        1012
#define IDC_PROGRESS1                   1012
#define IDC_BADD2COMPRESS2              1012
#define IDC_PROGRESS2                   1013
#define IDC_BUTTON1                     1014
#define IDC_FILENAME                    1015
#define IDC_FULLSIZE                    1016
#define IDC_COMPRESSEDSIZE              1017
#define IDC_RATIO                       1018
#define IDC_ELAPSEDTIME                 1019
#define IDC_REMAININGTIME               1020
#define IDC_CPRIORITY                   1022
#define IDC_CHECK1                      1023
#define IDC_RADIO_KGB                   1028
#define IDC_RADIO_ZIP                   1029
#define IDC_COMBO_SPAN                  1031
#define IDC_HELP                        1033
#define IDC_BRECENTARCH                 1034
#define IDC_CSHOWPASS                   1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
